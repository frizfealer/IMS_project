function [ llAry, comAry, llValAry, llVal ] = computell( y, s, pi, phi )
%computell compute log-likelihood
%k the number of trails
%y the count data (input)
%s the number of molecular species
%pi the probability of choosing each species (len(pi) = s)
%phi the probability of ionized (len(phi) = s)
startK = sum(y);
K = startK*15;
llAry =  sparse(zeros( K, 1 ));
comAry = sparse(zeros( K, 1));
logPAry = zeros( s+1,  1 );
llValAry = sparse(zeros( K, 1 ));
for i = 1:s
    logPAry(i) = log(pi(i))+log(phi(i));
end
for i = 1:s
    logPAry(s+1) = logPAry(s+1) + pi(i)*(1-phi(i));
end
logPAry(s+1) = log(logPAry(s+1)+1e-16);
llVal = 0;
prevk = startK;
prevllVal = 0;

%precomputed variables
oneProb = 0;
for i = 1:s
    oneProb = oneProb + logPAry(i)*y(i);
end
preFacAll = logfactorial_e(startK-1,1e8);
facY = zeros( size( y ) );
for i = 1:s
    facY(i) = logfactorial_e(y(i),1e8);
end
sumFacY = sum(facY);
sumY = sum(y);
preFacZ = 0;
for k = startK:K
    zNum = k - sumY;
    %eNumAry = [y; zNum];
    %P = perms_reps( 1:s+1, eNumAry );
    %totalP = zeros(size(P, 1), 1);
%     for i = 1:size(P, 1)
%         cCom = P(i, :);
%         totalP(i) = sum( logPAry(cCom) );
%     end
    if zNum > 0
        preFacZ = preFacZ + log(zNum);
    end
    preFacAll = preFacAll + log(k);
    numCom = preFacAll;
    numCom = numCom - sumFacY;
    numCom = numCom - preFacZ;
    %numCom = round(exp(numCom));
    %llAry(k) = oneProb + logPAry(s+1)*zNum;
    %comAry(k) = round(exp(preFacAll));
    llValAry(k) = numCom + oneProb + logPAry(s+1)*zNum;
    llVal = llVal + exp( numCom + oneProb + logPAry(s+1)*zNum );
    if k-prevk > startK*5
        prevk = k;
        if abs( llVal - prevllVal ) < 1e-16
            break;
        end
        prevllVal = llVal;
    end
end
% endK = k;
% maxVal = max(llValAry(startK:endK));
% llVal = log(sum(exp( llValAry(startK:endK) - maxVal ) ) )+maxVal;
end

