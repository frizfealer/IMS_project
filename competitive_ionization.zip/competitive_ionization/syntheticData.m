%% testing truncated distribution
pd = makedist( 'NegativeBinomial', 'R', 1, 'p', 1e-3 );
tpd = truncate( pd, 500, inf );
kVec = random( tpd, 10000, 1 );
hist( kVec, 100);

%% different parameters setting can generate similar data distribution
S = 2;
pi = zeros(S, 1); pi(1) = 0.5; pi(2) = 0.5;
phi = zeros(S,1); phi(1) = 0.6; phi(2) = 0.4;

pK = 1e-3;
[ y, kVec ] = genCount( 1000, pK, 2, 1e4, pi, phi );
%figure; hist(kVec, 100);
% figure; subplot(2,2,1); hist(y(1, :)); title('s = 1, pi = 0.5, phi = 0.6, pk = 1e-3, leastNum = 1000');
% subplot(2,2,2);hist(y(2, :)); title('s = 2, pi = 0.5, phi = 0.4, pk = 1e-3, leastNum = 1000' );
insVec = y(1,:) ./ y(2,:);
figure; subplot(1,2,1);hist(insVec, 100);
title( 'histogram of element 1/element 2. pi = [0.5 0.5], phi = [0.6 0.4], least-k = 1000' ); xlabel('y(1,:) ./ y(2, :)'); ylabel('counts');
mean(insVec)
std(insVec)

phi = ones(S, 1);
pi(1) = 0.6; pi(2)=0.4;
K = 1e-3;
[ y, kVec ] = genCount( 500, pK, 2, 1e4, pi, phi );
%figure; hist(kVec, 100);
%subplot(2,2,3);hist(y(:,1)); title('s = 1, pi = 0.6, phi = 1, k = 500');
%subplot(2,2,4);hist(y(:, 2)); title('s = 2, pi = 0.4, phi = 1, k = 500' );
insVec = y(1,:) ./ y(2,:);
subplot(1,2,2);hist(insVec, 100);
title( 'histogram of element 1/element 2. pi = [0.6 0.4], phi = [1 1], least-k = 500' ); xlabel('y(1,:) ./ y(2, :)'); ylabel('counts');
mean(insVec)
std(insVec)

%% showing the influences of different phi
S = 1;
pi = zeros(S, 1); pi(1) = 1;
phi = zeros(S,1); phi(1) = 0.7;

pK = [2e-2, 1e-2, 2e-3, 1e-3, 2e-4, 1e-4];
figure;
y = zeros(1e4, 6);
for i = 1:6
    [ y(:, i), kVec ] = genCount( 500, pK(i), 1, 1e4, pi, phi );
    subplot(2, 3, i); hist(y(:,i), 100); title(['p(y), sample number = 1e4, least k = 500, pk = ', num2str(pK(i))]);
end

figure;
y = zeros(1e4, 6);
for i = 1:6
    [ y(:, i), kVec ] = genCount( 1000, pK(i), 1, 1e4, pi, phi );
    subplot(2, 3, i); hist(y(:,i), 100); title(['p(y), sample number = 1e4, least k = 1000, pk = ', num2str(pK(i))]);
end


%k matters

%% test whether different pi, and phi lead to different log likelihood

y = y(1,:);
S = 2;
pi = zeros(S, 1); pi(1) = 0.6; pi(2) = 0.4;
phi = zeros(S,1); phi(1) = 1; phi(2) = 1;
[llInd1, cA1, llA1, ll1]=computell(y,S,pi,phi);

S = 2;
pi = zeros(S, 1); pi(1) = 0.5; pi(2) = 0.5;
phi = zeros(S,1); phi(1) = 0.6; phi(2) = 0.4;
[llInd2, cA2, llA2, ll2]=computell(y,S,pi,phi);

startPos = sum(y);
length(llA2) == length(llA1)
llValHist = zeros(length(llA2)-startPos+1, 2);
for i = 2:(length(llA2)-startPos+1)
    llValHist(i, 1) = llValHist(i-1, 1) + exp(llA1(startPos+i-2));
    llValHist(i, 2) = llValHist(i-1, 2) + exp(llA2(startPos+i-2));
end
figure; subplot(1,2,1); plot(llA1(startPos:end)); title( 'log-likelihood versus different k pi = [0.6 0.4], phi = [1 1]' );
ylabel('log-likelihood'); xlabel('k (start from sum(y))');
subplot(1,2,2); plot(llA2(startPos:end)); title( 'log-likelihood versus different k pi = [0.5 0.5], phi = [0.6 0.4]' );
ylabel('log-likelihood'); xlabel('k (start from sum(y))');

figure; plot(llValHist); title('accumulated log-likelihood versus different k');
ylabel('accumulated log-likelihood'); xlabel('k (start from sum(y))');
legend('pi = [0.6 0.4], phi = [1 1]', 'pi = [0.5 0.6] phi = [0.6 0.4]'); 

%%

S = 2;
pi = zeros(S, 1); pi(1) = 0.6; pi(2) = 0.4;
phi = zeros(S,1); phi(1) = 0.2; phi(2) = 0.2;
ll3 = zeros(100, 1);
for i = 1:100
    phi(1) = i*0.01; phi(2) = i*0.01;
    [~, ~, ~, ll3(i)]=computell(y,S,pi,phi);
end
figure; plot(ll3); title('fixed pi, change phi from 0.01 to 1');
xlabel( 'different phi'); ylabel('log-likelihood');

