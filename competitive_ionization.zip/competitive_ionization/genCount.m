function [ y, kVec ] = genCount( leastIonNum, pk, s, n, pi, phi )
% leastIonNum the least number of ion count
% pk probability of success in geometric distribution
% s the number of molecule species
% n the number of sample
% pi the probability of choosing each species (len(pi) = s)
% phi the probability of ionized (len(phi) = s)
% y a s by 1 vector
if size( pi, 1 ) > 1
    pi = pi';
end
if size( phi, 1 ) > 1
    phi = phi';
end
%k =  geornd(pk);
pd = makedist( 'NegativeBinomial', 'R', 1, 'p', pk );
tpd = truncate( pd, leastIonNum, inf );
kVec = random( tpd, n, 1 );

y = zeros( s, n );
idx = find( kVec ~= 0 );
for j = 1:length(idx)
    hi = gendist( pi, kVec(idx(j)), 1 );
    for i = 1:s
        numi = length( find( hi == i ) );
        if numi == 0
            y(i, idx(j)) = 0;
        else %numi ~=0
            tmp = gendist( [phi(i), 1-phi(i)], numi, 1 );
            y(i, idx(j)) = length( find( tmp == 1 ) );
        end
    end
end
end

