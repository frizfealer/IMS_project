function [ fval ] = complFVal( pk, phi, y )
%compFVal compute function values @11/25/2014
fval = log(pk) + y*log(1-pk) + y*log(phi) - (y+1)*log(pk+phi-pk*phi);


end

