function [ mDataCube, mMZAxis, iii, mIndVec ] = alignPeaks( dataCube, mzAxis, tol )
    [~, sNum] = size(dataCube);
    ins = dataCube;
    ins = sum( ins, 2 );
    [~,dOrd] = sort(ins, 'descend');
    dMZ = mzAxis(dOrd);
    mMZAxis = zeros( length(dMZ), 1 );
    mIndVec = zeros( length(dMZ), 1 );
    curPeakID = 1;
    iii = [];
    while ~isempty(dMZ)
%         fprintf( '%d\n', curPeakID );
%         idx = ismember( mzAxis, dMZ ) ;
%         tmp = ins(idx);
%         if max(tmp) ~= ins( mzAxis == dMZ(1) )
%             keyboard();
%         end
        lMZ = dMZ(1);
        rMZ = dMZ( dMZ >= lMZ - tol );
        rMZ = rMZ( rMZ <= lMZ + tol );
        mIndVec( ismember( mzAxis, rMZ )==1 ) = curPeakID;
        mMZAxis(curPeakID) = lMZ;
        iii(curPeakID) = length(rMZ);
        curPeakID = curPeakID + 1;
        rDOrd = find(ismember( dMZ, rMZ ));
%         fprintf( '%d, %d, %d\n', length(dMZ), length(rMZ), length(rDOrd) );
%         if length(rMZ) ~= length(rDOrd)
%             keyboard();
%         end
        dMZ(rDOrd) = [];
    end

    peakNum = max(mIndVec);
    tmp = mMZAxis;
    mMZAxis = tmp(1:peakNum);
    mMZAxis = sort( mMZAxis );
    mDataCube = zeros( peakNum, sNum );
    for i = 1:sNum
        curSpec = dataCube(:,i);
        startPos = 1;
        curPeakID = 1;
        for j = 1:length(mIndVec)-1
            if mIndVec(j+1) ~= mIndVec(j)
                endPos = j;
                mDataCube(curPeakID,i) = max(dataCube(startPos:endPos, i));
                startPos = j+1;
                curPeakID = curPeakID + 1;
            end
        end
        endPos = j+1;
        mDataCube(curPeakID,i) = max(dataCube(startPos:endPos, i));
    end
end