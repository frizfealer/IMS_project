function [ resMat, delta, resMat2, resMat3 ] = checkingBinFunction2( mappingFunc, mm, mzShift, indMat, dataVec, tolVec )
%--------------------------------------------------------------------------
% checkingBinFunction2: check to see if bin function makes the dictionary
% delta consistent across the sample grids.
%--------------------------------------------------------------------------
% DESCRIPTION:
%   (It is not used in current version.) This function computes some
%   properties of current binning, includes the fraction of m/z values in a
%   bin results in different bins after a delta.
%
% INPUT ARGUMENTS:
%   mappingFunc, a var. from binningDataCube, a mapping from the a set of indices in mzAxis to their binned m/z value in 
%   mm mzAxis, size of [s 1], a vector of m/z values of the input data
%   (original m/z values).
%   mzShift, mzShift collected from the positive or negative ion types
%   tables,
%   indMat, a matrix of original binning size*grid sizes that shows if a
%   peak exists in a particular grid. If exists, the entry is one;
%   otherwise, zero.
%   dataVec, a matrix of orginal data without binning.
%   tolVec, tolerance for different m/z values, currectly deprecated (set
%   as []).
% OUTPUT ARGUMENTS:
%   resMat, the fraction of each m/z values in a bin that are still in the
%   same bin after adding a delta; therefore, it is a matrix of [#bin
%   #delta]
%   delta, differences of m/z from ion type tables.
%   resMat2, the difference of m/z values in the same bin.
%   resMat3, the ratio of median values of possible different peaks adding
%   delta in the same bin

uniMZ = unique( mappingFunc );
binNum = length(uniMZ);
delta = mzShift - mzShift(1);
delta(1) = [];

interval = mzShift - mzShift(1);
mapping = zeros( length(mzShift), length(interval) );
for i = 1:length(mzShift)
    mapping(i,:) = interval - interval(i);
end
delta = unique( mapping(:) );
delta(delta==0) = [];

resMat = ones( binNum, length(delta) );
resMat2 = zeros( binNum, length(delta) );
resMat3 = zeros( binNum, length(delta) );
if isempty(tolVec)
    tolVec = 5e-4*ones(size(uniMZ));
elseif length(tolVec) == 1
    tolVec = tolVec*ones(size(unitMZ));
end
for i = 1:binNum
    %fprintf( '%d\n', i );
    ib = uniMZ(i);
    mappingIdx = find( mappingFunc == ib );
    if length(mappingIdx) == 1
        continue;
    end
    voteVec = sum( indMat(mappingIdx, :), 2 );
    pm = mm(  mappingIdx  );
    for j = 1:length(delta)
        %fprintf( '%d\n', j );
        cDelta = delta(j);
        pmShift = pm + cDelta;
        cb = arrayfun(@(x) binFunc(mappingFunc, mm, x, tolVec, uniMZ), pmShift );
        cIdx = arrayfun(@(x) findingMathcedPeaks( mm, x, tolVec ), pmShift );
        cb2 = binFunc(mappingFunc, mm, cDelta+ib, tolVec, uniMZ);
        mappingIdx_shift = zeros( length(mappingIdx), 1 );
        uniTmp = unique(cb); uniTmp(uniTmp==-1) = [];
        tmpCnt = zeros( length(uniTmp), 1);
        for z = 1:length(mappingIdx_shift)
            if cb(z) == -1
                mappingIdx_shift(z) = -1;
            else
                mappingIdx_shift(z) = find(uniMZ==cb(z));
            end
            tmpCnt( uniTmp == cb(z) ) = tmpCnt( uniTmp == cb(z) ) + voteVec(z);
        end
        [maxVal,maxIdx] = max(tmpCnt);
        if length(uniTmp) > 1
            resMat(i, j) = tmpCnt( maxIdx ) / sum(tmpCnt);
            resMat2(i, j) = max(pmShift)-min(pmShift);
            [~, sIdx] = sort(tmpCnt, 'descend' );
            pIdx1 = findingMathcedPeaks( mm, uniTmp(sIdx(1)), tolVec(sIdx(1)) );
            targetSam = find( dataVec(pIdx1,:) >=  max(dataVec(pIdx1,:))*1e-2 );
            pIdx2 = findingMathcedPeaks( mm, uniTmp(sIdx(2)), tolVec(sIdx(2)) );
            tmp = abs( dataVec(pIdx2, targetSam) - dataVec(pIdx1, targetSam) ) ./ dataVec(pIdx1, targetSam);
            tmp(isnan(tmp)) = [];
            tmp(tmp==inf) = [];
            resMat3(i ,j) = median( tmp );
        end
    end
end


end

function [mz] = binFunc( mappingFunc ,mm, t, tol, binMZ )
[~, idx] = min( abs(t - mm ) );
binIdx = find( mappingFunc == mappingFunc(idx) );
binRang = [mm(min(binIdx)), mm(max(binIdx))];
cTOL = tol( mappingFunc(binIdx(1)) == binMZ );
if t >= binRang(1) && t <= binRang(2)
    mz = mappingFunc(binIdx(1));
elseif t < binRang(1)
    if binRang(1) - t <= t*(cTOL/2)
        mz = mappingFunc(min(binIdx));
    else
        mz = -1;
    end
elseif t > binRang(2)
    if t - binRang(2) <= t*(cTOL/2)
        mz = mappingFunc(max(binIdx));
    else
        mz = -1;
    end
end
end

function [index] = findingMathcedPeaks( mzAxis, targetMZ, tol )
[val, idx] = min( abs(targetMZ - mzAxis ) );
if val <= targetMZ*tol
    index = idx;
else
    index = -1;
end
end