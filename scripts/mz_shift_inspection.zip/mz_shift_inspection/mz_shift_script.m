load( 'D:\IMS_DATA\100831_348_136_12,40hr_0-1XLB_LP\pick_peaking_no_other_preprocessing\100831_348_136_12,40hr_0-1XLB_LP.mzML_dc.mat' );
ins = mean( dataCube, 1 ); ins = reshape( ins, 38, 59 );
figure; imagesc2(ins); colorbar;

%% m/z versus max(m/z shift) plot for different 9 nearest neighbors of different spots
figure; 
xVec = zeros(9, 1);
yVec = zeros(9, 1);
for z = 1:9
    cnt = 1;
    startX = randi(10);
    startY = randi(46);
    xVec(z) = startX+4;
    yVec(z) = startY+9;
    fprintf('trail %d %d %d\n', z, xVec(z), yVec(z) );
    for i = 0:2
        for j = 0:2
            targetIdxX(cnt) = i+startX+4; %from 5 to 14
            targetIdxY(cnt) = j+startY+9; %from 10 to 54
            cnt = cnt + 1;
        end
    end
    targetIdx = sub2ind([38, 59], targetIdxX, targetIdxY );
    dd = dataCube(1:2e4, targetIdx);
    mm = mzAxis(1:2e4);
    %[ mDataCube, mMZAxis, iii, mIndVec ] = alignPeaks( dd, mm, 1 );
    [  res, mzRes, intRes, refSam ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5 );
    insMax = zeros( length( unique( mzRes ) ), 1 );
    tmp = unique(mzRes);
    for i = 1:length(insMax)
        idx = find( mzRes == tmp(i) );
        insMax(i) = max( abs( res(idx) ) );
    end
    subplot(3,3,z); plot(insMax); 
    set( gca, 'xtick', 1:20:length(insMax) );
    nameTag = tmp( 1:20:length(insMax) );
    for i = 1:length(nameTag)
        nameTag(i) =  round( nameTag(i)*100)/100;
    end
    set( gca, 'xticklabel', num2str(nameTag) );
    %xticklabel_rotate
    xlabel( 'm/z' ); ylabel( 'max( m/z shift )' ); title( ['8 near samples of (', num2str(xVec(z)), ', ' num2str(yVec(z)), ')'] );
end
ins = mean( dataCube, 1 ); ins = reshape( ins, 38, 59 );
for i = 1:9
    ins(xVec(i), yVec(i)) = 0;
end
figure; imagesc2(ins); colorbar;

%% show the m/z shifts across a line of the grid cells (row 8)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for r = 1
    for c = 1:48
        targetIdxR(cnt) = 7 + r;
        targetIdxC(cnt) = 8 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:6
   subplot(2, 3, i);
    if i == 6
        samRang = ((i-1)*8+2):(length(resCell));
        bar(barMat(:, [1 ((i-1)*8+2):(length(resCell))]));
    else
        samRang = ((i-1)*8+2):(i*8+1);
        bar(barMat(:, [1 ((i-1)*8+2):(i*8+1)]));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (row 12)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for r = 1
    for c = 1:48
        targetIdxR(cnt) = 11 + r;
        targetIdxC(cnt) = 8 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:6
   subplot(2, 3, i);
    if i == 6
        samRang = ((i-1)*8+2):(length(resCell));
        bar(barMat(:, [1 ((i-1)*8+2):(length(resCell))]));
    else
        samRang = ((i-1)*8+2):(i*8+1);
        bar(barMat(:, [1 ((i-1)*8+2):(i*8+1)]));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (row34)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for r = 1
    for c = 1:48
        targetIdxR(cnt) = 33 + r;
        targetIdxC(cnt) = 8 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:6
   subplot(2, 3, i);
    if i == 6
        samRang = ((i-1)*8+2):(length(resCell));
        bar(barMat(:, [1 ((i-1)*8+2):(length(resCell))]));
    else
        samRang = ((i-1)*8+2):(i*8+1);
        bar(barMat(:, [1 ((i-1)*8+2):(i*8+1)]));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (row26)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for r = 1
    for c = 1:48
        targetIdxR(cnt) = 25 + r;
        targetIdxC(cnt) = 8 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:6
   subplot(2, 3, i);
    if i == 6
        samRang = ((i-1)*8+2):(length(resCell));
        bar(barMat(:, [1 ((i-1)*8+2):(length(resCell))]));
    else
        samRang = ((i-1)*8+2):(i*8+1);
        bar(barMat(:, [1 ((i-1)*8+2):(i*8+1)]));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (col18)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for c = 1
    for r = 3:16
        targetIdxR(cnt) = r;
        targetIdxC(cnt) = 17 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:2
   subplot(1, 2, i);
    if i == 2
        samRang = [ 1 ((i-1)*7+2):(length(resCell)) ];
        bar(barMat(:, samRang));
    else
        samRang = [ 1 ((i-1)*7+2):(i*7+1) ];
        bar(barMat(:, samRang));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (col40)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for c = 40
    for r = 3:16
        targetIdxR(cnt) = r;
        targetIdxC(cnt) = c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:2
   subplot(1, 2, i);
    if i == 2
        samRang = [ 1 ((i-1)*7+2):(length(resCell)) ];
        bar(barMat(:, samRang));
    else
        samRang = [ 1 ((i-1)*7+2):(i*7+1) ];
        bar(barMat(:, samRang));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (col18, row22-37)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for c = 40
    for r = 22:37
        targetIdxR(cnt) = r;
        targetIdxC(cnt) = c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:2
   subplot(1, 2, i);
    if i == 2
        samRang = [ 1 ((i-1)*7+2):(length(resCell)) ];
        bar(barMat(:, samRang));
    else
        samRang = [ 1 ((i-1)*7+2):(i*7+1) ];
        bar(barMat(:, samRang));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% show the m/z shifts across a line of the grid cells (col40, row22-37)
cnt = 1;
targetIdxR = []; targetIdxC = [];
for c = 40
    for r = 22:37
        targetIdxR(cnt) = r;
        targetIdxC(cnt) = c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[  res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dataCube(1:2e4, targetIdx), mm, [], 0.5, 1 );

% create matrix for barplot
barMat = zeros(10, length(resCell) );
binVal = [-0.4, -0.3, -0.2 -0.1, 0 0.1 0.2 0.3 0.4 0.5];
for i = 1:length(resCell)
    cSam = resCell{i};
    for j = 1:length(cSam)
        idx = find( cSam(j) <= binVal );
        idx = min(idx);
        barMat(idx,i) = barMat(idx,i) + 1;
    end
end
figure;
set(gcf, 'position', [ 1          41        1366         650] );
for i = 1:2
   subplot(1, 2, i);
    if i == 2
        samRang = [ 1 ((i-1)*7+2):(length(resCell)) ];
        bar(barMat(:, samRang));
    else
        samRang = [ 1 ((i-1)*7+2):(i*7+1) ];
        bar(barMat(:, samRang));
    end
    ylabel( 'frequency' ); xlabel( 'm/z shifts' ); title( ['m/z shfit hist. of sample' num2str(samRang(1)) ' to sample', num2str(samRang(end))] );
    set(gca, 'xticklabel', ['[-0.5, -0.4]'; '[-0.4, -0.3]'; '[-0.3, -0.2]'; '[-0.2, -0.1]'; ...
        '[-0.1,  0.0]'; '[ 0.0,  0.1]'; '[ 0.1,  0.2]'; '[ 0.2,  0.3]'; '[ 0.3,  0.4]'; '[ 0.4,  0.5]'] );
    xticklabel_rotate
    legName = num2str(samRang');
    legLab = cell( length(samRang)+1, 1 );
    legLab{1} = 'refSam';
    for j = 1:length(samRang)
        legLab{j+1} = ['sam' legName(j, :)];
    end
    %legend(legLab);
end

%% checking if the distances of the highest peaks in each bin to the bin's boundaries peaks.
dd = dataCube(1:2e4, :);
mm = mzAxis(1:2e4);
BlkDS = conBLKDS(dataCube(1:2e4, :, :));
dd(dd<100)=0;
[ mDataCube, mMZAxis, iii, binMap ] = binningDataCube( dd, mm, BlkDS );
indMap = binMap(:, BlkDS.indMap == 1);
figure ;hist(indMap(:), 10); title('histogram of maximun distance of the largest peak''s m/z to the boundary values in the bin');
[ mDataCube, mMZAxis, iii, binMap, mappingFunc, mMZAxis2, binMap2 ] = binningDataCube( dd, mm, BlkDS );

% 
% meanVec = zeros( length(mMZAxis), 1);
% stdVec = zeros( size(meanVec) );
% for i = 1:length(mMZAxis)
%     meanVec(i) = mean(binMap(i, BlkDS.indMap ==1));
%     stdVec(i) = std(binMap(i, BlkDS.indMap ==1));
% end
% %meanVec>0.8 means the largest peaks have average distances 0.2 from the bin
% %boundary
% idx = find(meanVec>=0.8);
% xName = zeros( size(idx) );
% for i = 1:length(idx)
%     xName(i) = round(mMZAxis(idx(i))*100)/100;
% end
% errorbar(meanVec(meanVec>=0.8),stdVec(meanVec>=0.8)); 
% cXtick = get( gca, 'xtick' ); cXtick(cXtick<0) = []; cXtick(1) = 1; cXtick(end) = size(xName, 1); 
% set( gca, 'xtick', cXtick ); set( gca, 'xticklabel', xName(cXtick, :) ); 
% xlabel( 'm/z' ); ylabel( 'average distance of the largest peaks to its bin boundaries' );

%% checking if f(m+d) = f(f(m)+d), f is the binning funciton.
[ mDataCube, ~, iii, ~, ~,  mMZAxis2, binMap2, mappingFunc2 ] = binningDataCube( dd, mm, BlkDS );
peakNum = 10;
 [ resCell ] = checkingBinFunction( mappingFunc2, mm, peakNum, []);
 MPPATH = 'D:\Users\YeuChern\GitHub\IMS_project\example\molecule_profile_pos.csv';
fileID = fopen(MPPATH);
C = textscan(fileID, '%f %s', 'delimiter', {','});
fclose(fileID);
mpAry = C{1,1};
nameAry = C{1,2};
peakNum = 1e4;
[ resCell2 ] = checkingBinFunction( mappingFunc2, mm, peakNum, mpAry);


%% show the largest m/z difference of each cell grids
ins3 = zeros(length(targetIdx), 1);
for i = 1:length(targetIdx)
    ins = find(dd(:,i)~=0);
    tmp = min(diff(ins));
    tmp = find( diff(ins) == tmp );
    tmp = tmp(end);
    ins3(i) = mzAxis(ins(tmp+1)) - mzAxis(ins(tmp));
end
ins3

%% show the m/z difference versus the increase of m/z, with different intBin
intBin = 10;
tmp = zeros(length(mm), 1);
for i = 1:length(mm)
    if i <= intBin
        tmp(i) = mm(i+intBin) - mm(i);
    elseif i >= length(mm) - intBin
        tmp(i) = mm(i) - mm(i-intBin);
    else
        tmp(i) = max( mm(i) - mm(i-intBin), mm(i+intBin) - mm(i) );
    end
end
figure; plot(tmp); title( ['# bin = ', num2str(intBin)] );

%% overview plot of peak of each cell grids
ins2 = zeros( length(targetIdx), 1 );
for i = 1:length(targetIdx)
    ins = find(dd(:,i)~=0);
    ins2(i) = length(ins);
end
[~,idx] = max(ins2);

ins = find(dd(:,idx)~=0);
ins2 = ins;
tmp= max( mzAxis(ins) - mzAxis(ins-intBin), mzAxis(ins+intBin) - mzAxis(ins) );
for i = 1:length(ins)
    ins2 = [ins2; ((ins(i)-intBin):(ins(i)+intBin))'];
end
ins2 = unique(ins2);
figure; imagesc2(dd(ins2,:)); title( 'overview plot of peak of each nine grid cells' );

%% show if there are variance of m/z shift between different m/z
intBin = 10;
tmp = zeros( length(ins), 2 );
for i = 1:length(ins)
    tRang = (ins(i)-intBin):(ins(i)+intBin);
    [r, c ] = find( dd( tRang, :) );
    qqq = unique(c);
    ddd = [];
    for j = 1:length(qqq)
        if length(find( c == qqq(j) ) ) > 1
            ttt = find( c == qqq(j) );
            [~, idx] = min( abs( ins(i) - tRang(ttt) ) );
            ddd = [ddd; setdiff(ttt,ttt(2))];
        else
        end
    end
    r(ddd) = [];
    fprintf( '%d %g %g %g %g \n', ins(i), mm( tRang( min(r) ) ), mm( tRang( max(r) ) ), mm( tRang( max(r) ) ) - mm( tRang( min(r) ) ), ...
     ( mm( tRang( max(r) ) ) - mm( tRang( min(r) ) ) )/ 2 /  mm( tRang( max(r) ) ));
    tmp(i, 1) =  mm( tRang( max(r) ) ) - mm( tRang( min(r) ) );
    tmp(i, 2) =   ( mm( tRang( max(r) ) ) - mm( tRang( min(r) ) ) )/ 2 /  mm( tRang( max(r) ) );
end
[~, ord] = sort(tmp(:,2), 'descend' );
idx = ins(ord(1));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));
mm(tRang(55))-mm(tRang(47))

%% variance between nine cell grids
mzDiff = zeros(9, 1);
for z = 1:9
cnt = 1;
startX = randi(11);
startY = randi(45);
fprintf('trail %d %d %d\n', z, startX, startY );
for i = 1:3
    for j = 1:3
        targetIdxX(cnt) = i+startX+2;
        targetIdxY(cnt) = j+startY+8;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxX, targetIdxY );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[ tmp ] = computeMZshiftSta( targetIdx, dd, mm );
mzDiff(z) = max(tmp(:, 2));
end





cnt = 1;
for r = 1
    for c = 1:48
        targetIdxR(cnt) = 7 + r;
        targetIdxC(cnt) = 8 + c;
        cnt = cnt + 1;
    end
end
targetIdx = sub2ind([38, 59], targetIdxR, targetIdxC );
dd = dataCube(1:2e4, targetIdx);
mm = mzAxis(1:2e4);
[ mzDiff ] = computeMZshiftSta( targetIdx, dd, mm );

[~, ord] = sort(mzDiff(:,2), 'descend' );
idx = ins(ord(1));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));
idx = ins(ord(2));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));
idx = ins(ord(3));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));
idx = ins(ord(4));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));
idx = ins(ord(5));
tRang = idx-10:idx+10;
figure; imagesc2(dd(tRang,:));

%% using the original method to see if shift become larger
dd = dataCube(1:2e4, :);
mm = mzAxis(1:2e4);
[ mDataCube, mMZAxis, iii, mIndVec ] = alignPeaks( dd, mm, 1e-4*5 );

res = zeros( max(mIndVec), 1 );
for i = 1:max(mIndVec)
    idx = find(mIndVec==i);
    res(i) = (mm(idx(end)) - mm(idx(1)) );
end