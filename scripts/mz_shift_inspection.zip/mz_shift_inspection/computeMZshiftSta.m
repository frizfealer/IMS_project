function [ res, mzRes, intRes, refSam, resCell ] = computeMZshiftSta( dd, mm, intBin, mzshift, refSam )
samNum = size(dd, 2);
ins2 = zeros( samNum, 1 );
for i = 1:samNum
    ins = find(dd(:,i)~=0);
    ins2(i) = length(ins);
end
[~,idx] = max(ins2);
if isempty( refSam )
    refSam = idx;
end
ins = find(dd(:, refSam)~=0);

if ~isempty(mzshift)
    mzFlag = 1;
end
mzDiff = zeros( length(ins), 2);
INT_THRES = 200;
res = [];
intRes = [];
mzRes = [];
cnt = 1;
resCell = cell( samNum, 1 );
for i = 1:length(ins)
    if mzFlag == 1
        [~, lIdx] = min( abs( mm - ( mm(ins(i))-mzshift ) ) );
        [~, hIdx] = min( abs( mm  - ( mm(ins(i))+mzshift ) ) );
        tRang = lIdx:hIdx;
    else
        tRang = (ins(i)-intBin):(ins(i)+intBin);
    end
    tmp = dd(tRang, :);
    intRes = [intRes; tmp(  tmp ~=0  )];
    [r, c ] = find( dd( tRang, :) >= INT_THRES );
    for j = 1:samNum
        idx =  find( c == j ) ;
        if ~isempty(idx)
            resCell{j} =  [resCell{j}; mm( tRang( r(idx) ) ) - mm(ins(i))];
            res = [res; mm( tRang( r(idx) ) ) - mm(ins(i))];
            mzRes = [ mzRes; repmat( mm(ins(i)), length(idx), 1)];
        end
    end
end


end

