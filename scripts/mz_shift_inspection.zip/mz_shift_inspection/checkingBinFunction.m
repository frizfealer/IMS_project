function [ resMat, delta, resMat2 ] = checkingBinFunction( mappingFunc, mm, mzShift, dataMatrix )
uniMZ = unique( mappingFunc );
binNum = length(uniMZ);
delta = mzShift - mzShift(1);
delta(1) = [];

interval = mzShift - mzShift(1);
mapping = zeros( length(mzShift), length(interval) );
for i = 1:length(mzShift)
    mapping(i,:) = interval - interval(i);
end
delta = unique( mapping(:) );
delta(delta==0) = [];

resMat = zeros(length(binNum), length(delta));
resMat2 = zeros(length(mm), length(delta));
for i = 1:binNum
    if i == 25
        keyboard
    end
    fprintf( '%d\n', i );
    ib = uniMZ(i);
    mappingIdx = find( mappingFunc == ib );
    pm = mm(  mappingIdx  );
    for j = 1:length(delta)
        fprintf( '%d\n', j );
        cDelta = delta(j);
        pmShift = pm + cDelta;
        cb = arrayfun(@(x) binFunc(mappingFunc, mm, x), pmShift );
        uniTmp = unique(cb);
        if length(uniTmp) > 1
            tmpCB = cb;
            for z = 1:length(cb)
                if cb(z) == -1
                    tmpCB(z) = -1;
                else
                    tmpCB(z) = find(uniMZ==cb(z));
                end
            end
            resMat2(mappingIdx, j) = tmpCB;
            resMat(i, j) = 1;
        end
    end
end


end

function [mz] = binFunc( mappingFunc ,mm, t )
[~, idx] = min( abs(t - mm ) );
binIdx = find( mappingFunc == mappingFunc(idx) );
binRang = [mm(min(binIdx)), mm(max(binIdx))];
if t >= binRang(1) && t <= binRang(2)
    mz = mappingFunc(binIdx(1));
elseif t < binRang(1)
    if abs(t - binRang(1)) < 0.25
        mz = mappingFunc(min(binIdx));
    else
        mz = -1;
    end
elseif t > binRang(2)
    if abs(t - binRang(2)) < 0.25
        mz = mappingFunc(max(binIdx));
    else
        mz = -1;
    end
end
end