%load data
BlkDS = conBLKDS( dataCube );
[ mDataCube, mMZAxis, iii ] = binningDataCube( dataCube, mzAxis, BlkDS );
mMZAxis([64:72])'
ins = zeros(size(mDataCube, 1), 1);
for i = 1:size(mDataCube, 1)
    ins(i) = max(mDataCube(i,:));
end
%65, 66
figure; imagesc( reshape( mDataCube(65, :), 38, 59 ) ); colorbar;
figure; imagesc( reshape( mDataCube(66, :), 38, 59 ) ); colorbar; %# samples is small.
%71, 72
figure; imagesc( reshape( mDataCube(71, :), 38, 59 ) ); colorbar;
figure; imagesc( reshape( mDataCube(72, :), 38, 59 ) ); colorbar; %area distribution is not similar to 1030 and 1044

target=mDataCube([65,69,71],:);
ins = sum(target, 1);
tSample = find( ins > 0 );
target = target(:, (ins>0));
figure; imagesc(target(:,:));
 [label, model, L] = vbgm(target(:, :), 10);
 figure;
for i = 1:max(label)
    subplot(2, 5, i);
    plot(target(:,label==i)); title(['group ' num2str(i)]);
end
for i = 1:max(label)
tmp = zeros(38,59);
tmp(tSample(label==i)) = mDataCube(65,tSample(label==i));
figure; subplot(1,3,1); imagesc(tmp); colorbar;
tmp = zeros(38,59);
tmp(tSample(label==i)) = mDataCube(69,tSample(label==i));
subplot(1,3,2); imagesc(tmp); colorbar;
tmp = zeros(38,59);
tmp(tSample(label==i)) = mDataCube(71,tSample(label==i));
subplot(1,3,3); imagesc(tmp); colorbar;
end

%Indices = crossvalind('Kfold', 10*length(find(BlkDS.indMap==1)), 5);
cNum = round(10*(0.1));
samNum = length(find(BlkDS.indMap == 1 ) );
newIndices = zeros(10, samNum );
for i = 1:samNum
    tmp =randperm( 10, 10);
    for j = 1:10
        target = [j];
        newIndices( ismember(tmp, target) , i ) = j;
    end
end
%% original domain
ins = zeros(size(mDataCube, 1), 1);
for i = 1:size(mDataCube)
    tmp = corrcoef(mDataCube(71,BlkDS.indMap==1), mDataCube(i,BlkDS.indMap==1));
    ins(i) = tmp(1,2);
end
ins = abs(ins);
figure;plot(ins); title( 'correlation coef. between 1058 m/z and other m/zs' );
[~,ord] = sort( ins, 'descend' );
target = mDataCube(sort(ord(1:10)),:);
D_CONSTRAINT = 1;
DCell = cell(10, 1);
resCell = cell(10, 1);

for k = 1:3
    resCell{k} = zeros(10, 1);
    DCell = cell(5,1); WCell = cell(5,1); LPCell = cell(5,1); DinitCell = cell(5, 1); DhistCell = cell(5, 1); WhistCell = cell(5, 1); covCell = cell(5, 1);
    for i = 1:10
        test = (newIndices == i); train = ~test;
        tBlkDS = BlkDS;
        tBlkDS.mask = zeros( 10,  samNum );
        tBlkDS.mask(train) = 1;
        [ DCell{i}, WCell{i}, ~, ~, ~, ~,~ ] = ALS_D_constraint( target, k, D_CONSTRAINT, tBlkDS, [],300 );
%         [ ~, ~, ~, ~, DinitCell{i}, DhistCell{i}, WhistCell{i} ] = ALS_D_constraint( target, k, D_CONSTRAINT, tBlkDS, [] );

        resCell{k}(i) = computeRes( target, DCell{i},  WCell{i}, tBlkDS );
    end
    %save('result20150211.mat');
end


tBlkDS = BlkDS;
tBlkDS.mask = ones( 10,  samNum );
[ D_C_k_2, W_C_k2 ] = ALS_D_constraint( target, 2, D_CONSTRAINT, tBlkDS, [], 500 );
[ D_C_k_3, W_C_k3 ] = ALS_D_constraint( target, 3, D_CONSTRAINT, tBlkDS, [], 500 );
[ D_C_k_4, W_C_k4 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, tBlkDS, [], 500 );

ins = zeros( 10, 5);
for i = 1:5
    ins(:, i) = DCell{i}(:,1);
end
ins(:, 6) = D_C_k_2(:,1);
figure; plot(ins); title('dictionay element 1 with k = 2 from different folds'); legend( 'fold1', 'fold2', 'fold3', 'fold4', 'fold5', 'all data');
ins = zeros( 10, 6);
for i = 1:5
    ins(:, i) = DCell{i}(:,2);
end
ins(:, 6) = D_C_k_2(:,2);
figure; plot(ins); title('dictionay element 2 with k = 2 from different folds'); legend( 'fold1', 'fold2', 'fold3', 'fold4', 'fold5', 'all data');

i = 1;
preX = DCell{i}*WCell{i};
resSq = (target(:, tBlkDS.indMap==1)-preX(:, tBlkDS.indMap==1)).^2;
figure; imagesc2(resSq); title( 'residual error squares across all data entries' ); colorbar;

i=1;
tBlkDS = BlkDS;
tBlkDS.mask = zeros( 10,  samNum );
tBlkDS.mask(train) = 1;
[ D_C_k_2_2, W_C_k2_2 ] = ALS_D_constraint( target, 2, D_CONSTRAINT, tBlkDS, D_C_k_2 );
ins = zeros( 10, 2);
for i = 1:1
    ins(:, i) = D_C_k_2(:,1);
end
ins(:, 2) = D_C_k_2_2(:,1);
figure; plot(ins); title('dictionay element 1 with k = 2 from all data grids and fold1 with better init.'); legend( 'all data grids', 'fold1 w. better init.' );
ins = zeros( 10, 2);
for i = 1:1
    ins(:, i) = D_C_k_2(:,2);
end
ins(:, 2) = D_C_k_2_2(:,2);
figure; plot(ins); title('dictionay element 2 with k = 2 from all data grids and fold1 with better init.'); legend( ' all data grids', 'fold1 w. better init');

tmp = target(:, tBlkDS.indMap==1);
for i = 1:5
    ins = newIndices==i;
    sum(ins(1,1:437))
    ins = ins .* tmp;
    %figure ;imagesc2(ins); colorbar;
end

i = 1;
preX = D_C_k_2_2*W_C_k2_2;
resSq = (target(:, tBlkDS.indMap==1)-preX(:, tBlkDS.indMap==1)).^2;
figure; imagesc2(resSq); title( 'residual error squares across all data entries (with trained D initialization)' ); colorbar;

for i = 1:5
    ins = newIndices == i;
    ins = ins .* target(:, tBlkDS.indMap==1);
    figure; hist(ins(1,:), 200);
end

stdAry=zeros(8,1);
for i = 1:8
    stdAry(i) = std(resCell{i});
end
meanAry = zeros( 3, 1);
for i = 1:8
    meanAry(i) = mean(resCell{i});
end
figure
errorbar(meanAry,stdAry)
for i = 1:5
    ins = zeros(8,1);
    for j = 1:8
    ins(j) = resCell{j}(i);
    end
    figure;plot(ins);
end

tBlkDS = BlkDS;
tBlkDS.mask = ones( 10,  samNum );
[ D_C1, W_C1 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, tBlkDS );
[ D_C1_k_3, W_C1_k_3 ] = ALS_D_constraint( target, 3, D_CONSTRAINT, BlkDS );
[ D_C1_k_4, W_C1_k_4 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, BlkDS );
[ D_C1_k_5, W_C1_k_5 ] = ALS_D_constraint( target, 5, D_CONSTRAINT, BlkDS );

%% on log domain
ins = zeros(size(mDataCube, 1), 1);
for i = 1:size(mDataCube)
    t1 = log(mDataCube(71,BlkDS.indMap==1)); t1(t1==-inf) = 0;
    t2 = log(mDataCube(i,BlkDS.indMap==1)); t2(t2==-inf) = 0;
    tmp = corrcoef(t1, t2);
    ins(i) = tmp(1,2);
end
ins = abs(ins);
figure;plot(ins)
[~,ord2] = sort( ins, 'descend' );
target = log(mDataCube(sort(ord2(1:10)),:)); target(target==-inf) = 0;
D_CONSTRAINT = 1;
DCell = cell(10, 1);
resCell2 = cell(8, 1);
%Indices = crossvalind('Kfold', length(find(BlkDS.indMap==1)), 5);
DinitCell = cell(10, 1);
for k = 1
    resCell2{k} = zeros(5, 1);
    for i = 1:10
        test = (newIndices == i); train = ~test;
        tBlkDS = BlkDS;
        tBlkDS.mask = zeros( 10,  samNum );
        tBlkDS.mask(train) = 1;
        [ DCell{i}, WCell{i}, LPCell{i}, ~, DinitCell{i}, ~, ~ ] = ALS_D_constraint( target, k, D_CONSTRAINT, tBlkDS, [], 500 );
        resCell2{k}(i) = computeRes( target, DCell{i},  WCell{i}, tBlkDS );
    end
    %save('result20150217.mat');
end
stdAry2=zeros(4,1);
for i = 1:4
    stdAry2(i) = std(resCell2{i});
end
meanAry2 = zeros( 4, 1);
for i = 1:4
    meanAry2(i) = mean(resCell2{i});
end
figure
errorbar(meanAry2,stdAry2);
tBlkDS = BlkDS;
tBlkDS.mask = ones( 10,  samNum );
[ D_C2, W_C2 ] = ALS_D_constraint( target, 2, D_CONSTRAINT, tBlkDS, [],500 );
[ D_C3, W_C3 ] = ALS_D_constraint( target, 3, D_CONSTRAINT, tBlkDS, [], 500 );
[ D_C4, W_C4 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, tBlkDS, [], 500);

save('result20150211.mat');

[ D_C2_k_4, W_C2_k_4 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, BlkDS );

%% on log domain
ins = zeros(size(mDataCube, 1), 1);
for i = 1:size(mDataCube)
    t1 = log(mDataCube(49,BlkDS.indMap==1)); t1(t1==-inf) = 0;
    t2 = log(mDataCube(i,BlkDS.indMap==1)); t2(t2==-inf) = 0;
    tmp = corrcoef(t1, t2);
    ins(i) = tmp(1,2);
end
ins = abs(ins);
figure;plot(ins)
[~,ord2] = sort( ins, 'descend' );
target = log(mDataCube(sort(ord2(1:10)),:)); target(target==-inf) = 0;
D_CONSTRAINT = 1;
DCell = cell(10, 1);
resCell2 = cell(8, 1);
%Indices = crossvalind('Kfold', length(find(BlkDS.indMap==1)), 5);
DinitCell = cell(10, 1);

DinitCell = cell(10, 1);
for k = 1:4
    resCell2{k} = zeros(5, 1);
    for i = 1:10
        test = (newIndices == i); train = ~test;
        tBlkDS = BlkDS;
        tBlkDS.mask = zeros( 10,  samNum );
        tBlkDS.mask(train) = 1;
        [ DCell{i}, WCell{i}, LPCell{i}, ~, DinitCell{i}, ~, ~ ] = ALS_D_constraint( target, k, D_CONSTRAINT, tBlkDS, [], 100 );
        resCell2{k}(i) = computeRes( target, DCell{i},  WCell{i}, tBlkDS );
    end
    %save('result20150217.mat');
end
stdAry2=zeros(4,1);
for i = 1:4
    stdAry2(i) = std(resCell2{i});
end
meanAry2 = zeros( 4, 1);
for i = 1:4
    meanAry2(i) = mean(resCell2{i});
end
figure
errorbar(meanAry2,stdAry2);


tBlkDS = BlkDS;
tBlkDS.mask = ones( 10,  samNum );
[ D_C2, W_C2 ] = ALS_D_constraint( target, 2, D_CONSTRAINT, tBlkDS, [],500 );
[ D_C3, W_C3 ] = ALS_D_constraint( target, 3, D_CONSTRAINT, tBlkDS, [], 500 );
[ D_C4, W_C4 ] = ALS_D_constraint( target, 4, D_CONSTRAINT, tBlkDS, [], 500);