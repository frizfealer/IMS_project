function [ res ] = computeRes( X, D, W, tBlkDS )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
preX = D*W;
testMask = double(tBlkDS.mask==0);
res = sum(sum( (testMask.*(X(:, tBlkDS.indMap==1)-preX(:, tBlkDS.indMap==1))).^2 ));

end

