function [ D, W, LPAry, tmpLPAry, Dinit, Dhist, Whist] = ALS_D_constraint( X, k, D_CONSTRAINT, BlkDS, Dinit, varargin )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%initialize

mask = BlkDS.mask;
XValSam = X(:, BlkDS.indMap==1);
meanXVal = mean(XValSam(mask==1));
stdXVal = std(XValSam(mask==1));
XValSam(mask==0) = abs(stdXVal/2*randn(length(find(mask==0)), 1))+meanXVal;
opt = statset('MaxIter',1e5,'Display','final');
% [D,~] = nnmf(XValSam,k,'options',opt,'algorithm','als');
[D,~] = nnmf(XValSam, k,'replicates',100,...
                   'options',opt,...
                   'algorithm','mult');
if ~isempty(Dinit)
    D = Dinit;
end
% ins = max( XValSam, [], 2);
% [~,ord] = sort(ins, 'descend');
% D = zeros( size(XValSam, 1), k );
% for i = 1:k
%     D(ord(i), i) = 1;
% end
% 
% ins = sum(D, 1);
% while ~isempty( find(ins == 0, 1) )
%     [D,~] = nnmf(XValSam,k,'options',opt,'algorithm','als');
%     ins = sum(D, 1);
% end
if ~isempty( varargin )
    OUTER_LOOP_NUM = varargin{1};
else
    OUTER_LOOP_NUM = 100;
end
LP_TOL = 1e-10;
D_TOL = 1e-4;
W_TOL = 1e-4;
if D_CONSTRAINT == 1
    for i = 1:k
        D(:, i) = D(:, i) / norm(D(:, i), 1);
    end
elseif D_CONSTRAINT == 2
    for i = 1:k
        D(:, i) = D(:, i) / norm(D(:, i), 2);
    end 
end
Dinit=D;
Dhist = cell( OUTER_LOOP_NUM, 1);
Whist = cell( OUTER_LOOP_NUM, 1 );
X = X(:, :);
tmpW = zeros( k, size(XValSam, 2) );
W = zeros( k, size(X, 2) );
LPAry = zeros( OUTER_LOOP_NUM+1, 1);
LPAry(1) = LLFunc( X, D, W, mask, BlkDS );
tmpLPAry = zeros( OUTER_LOOP_NUM, 2);

for it = 1:OUTER_LOOP_NUM
    prevW = W;
%     Dp1 = [D ones(size(D, 1), 1)];
    for i = 1:size(XValSam, 2)
        tIdx = find( mask(:, i) == 1 );
        opt = optimset();opt.TolX = 1e-6;
        ins = max( D(tIdx,:),[],1 );
        targetIdx =  ins > 1e-2 ;
        tmp = lsqnonneg( D(tIdx, targetIdx==1), XValSam(tIdx,i),  opt );
        tmpW(targetIdx, i) = tmp;
        tmpW(~targetIdx, i) = 0;
    end
    W(:, BlkDS.indMap==1)=tmpW;
    
    tmpLPAry(it, 1) = LLFunc( X, D, W, mask, BlkDS );
    prevD = D;
    XX = sparse(XValSam);
    WW = W(1:k, BlkDS.indMap==1);
%     staticTerm = repmat( W(k+1, BlkDS.indMap==1), size(XX, 1), 1 );
    staticTerm = zeros( size(XX, 1), size(XX, 2) );
    Din = D(:);
    options.lb = zeros(length(Din),1);
    options.ub = ones(length(Din),1);
    options.cl = -Inf(size(D,2),1);
    options.cu = ones(size(D, 2),1);
    % Set the IPOPT options.
    options.ipopt.print_level = 2;
    % options.ipopt.jac_d_constant   = 'yes';
    % options.ipopt.hessian_constant = 'yes';
    options.ipopt.mu_strategy      = 'adaptive';
    options.ipopt.max_iter         = 200;
    options.ipopt.tol              = 1e-8;
    options.ipopt.hessian_approximation = 'limited-memory';
    options.ipopt.limited_memory_max_history = 1500;
    options.ipopt.honor_original_bounds = 'yes';
    options.ipopt.bound_relax_factor = 0;
    funcs.objective         = @objective;
    funcs.gradient          = @gradient;
    if D_CONSTRAINT == 1
        funcs.constraints  = @constraints_L1;
        funcs.jacobian          = @jacobian_L1;
    elseif D_CONSTRAINT == 2
        funcs.constraints  = @constraints_L2;
        funcs.jacobian          = @jacobian_L2;
    end
    funcs.jacobianstructure = @jacobianstructure;
    options.ipopt.derivative_test = 'first-order'; 
    options.ipopt.derivative_test_perturbation = 3e-6; 
    jacobStruct = zeros(size(D, 2), length( Din ) );
    cLoc = 1;
    for i = 1:size(D, 2)
        jacobStruct(i, (cLoc:cLoc+size(D, 1)-1)) = 1;
        cLoc = cLoc + size(D, 1);
    end
    jacobStruct = sparse(jacobStruct);
    
    options.auxdata = { XX, WW, staticTerm, jacobStruct, mask };
    [dd, info] = ipopt_auxdata(Din,funcs,options);
    D = reshape(dd, size(D, 1), size(D, 2));
    tmpLPAry(it, 2) = LLFunc( X, D, W, mask, BlkDS );
    tmp1 = max( abs( W(:)-prevW(:) ) );
    tmp3 = max( abs( D(:)-prevD(:) ) );
    LPAry(it+1) = LLFunc( X, D, W, mask, BlkDS );
    fprintf( 'itNum: %d\t diff D: %g\t, diff W: %g\n', it, tmp3, tmp1);
    if abs(LPAry(it+1)-LPAry(it)) <= LP_TOL*LPAry(it+1) && ...
            ( tmp1 < W_TOL &&  tmp3 < D_TOL ) %|| ...
        %( tmp3 < D_TOL && dfWHoldFlag == 1 )
        break;
    end
    Dhist{it} = D;
    Whist{it} = W;
end
end

function val = LLFunc( X, D, W, mask, BlkDS )
% Dp1 = [D ones(size(D, 1), 1)];
preX = D*W(:, BlkDS.indMap == 1);
val = sum( sum( (mask.*(preX - X(:, BlkDS.indMap == 1 ))).^2 ) );
end

function f = objective (x, auxdata)
%x is current D
[XX, WW, staticTerm, mask] = deal(auxdata{[1 2 3 5]});
% D = sparse( nonZPosY, nonZPosX, x, size(Y, 1), size(W, 1) );
% gPreY = staticTerm + D * W;
% gEPreY = exp( gPreY );
D = reshape( x, size(XX, 1), size(WW, 1));
preX = staticTerm + D * WW;
% f = -Y.* preY + ePreY;
f = sum( sum( (mask.*(XX - preX )).^2 ) );
end

function gRes = gradient (x, auxdata)
gRes = zeros( size(x) );
[XX, WW, staticTerm, mask] = deal(auxdata{[1 2 3 5]});
D = reshape( x, size(XX, 1), size(WW, 1));
preX = staticTerm + D * WW;
% gRes = (-Y+ePreY)*WT;
% gRes = gRes(nonZPos);
curLoc = 1;
for i = 1:size(D, 2)
    gRes(curLoc:(curLoc+size(D, 1)-1)) = -2*( mask .*( XX - preX ) )*WW(i, :)';
    curLoc = curLoc + size(D, 1);
end
end

function c = constraints_L1(x, auxdata)
[XX, WW] = deal(auxdata{[1 2]});
D = reshape( x, size(XX, 1), size(WW, 1));
c = sum(D, 1);
end

function c = constraints_L2(x, auxdata)
[XX, WW] = deal(auxdata{[1 2]});
D = reshape( x, size(XX, 1), size(WW, 1));
c = sum(D.^2, 1);
end

function J = jacobian_L2 (x, auxdata)  
[XX, WW] = deal(auxdata{[1 2]});
sLen = size(XX, 1);
cNUM = size(WW, 1);
J = zeros( cNUM, length( x ) );
it = 1;
for i = 1:cNUM
    J(i, it:(it+sLen-1)) = 2*x(it:(it+sLen-1));
    it = it + sLen;
end
J = sparse(J);
end

function J = jacobian_L1 (x, auxdata)  
[J] = deal(auxdata{4});
end

function J = jacobianstructure (auxdata)
[J] = deal(auxdata{4});
end