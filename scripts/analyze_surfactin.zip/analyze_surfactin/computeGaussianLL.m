function [ LLVal ] = computeGaussianLL( X,D,W )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
varX = var(X(:));
n = size(X, 1)*size(X, 2);
% preX = [D ones(size(D, 1), 1)]*W;
preX = D*W;
LLVal = -n/2*log(2*pi*varX) - 1/(2*varX)*sum( (X(:)-preX(:)).^2 );

end

