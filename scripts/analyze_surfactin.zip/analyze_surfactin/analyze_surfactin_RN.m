load('surfactin_RN.mzML_raw_dc.mat'); 
figure; plot(dataVec); title('surfactin RN raw' );
load('surfactin_LN.mzML_raw_dc.mat'); 
figure; plot(dataVec); title('surfactin LN raw' );
tol = 1;
if min(diff(mzAxis))< tol
    [ dataVec, mzAxis, binNumVec ] = binningSpectrum( dataVec, mzAxis, tol );
end
dataVec_RN = dataVec; mzAxis_RN = mzAxis;

load('surfactin_LN.mzML_dc.mat'); 
tol = 0.5;
if min(diff(mzAxis)) > tol
    [ dataVec, mzAxis, binNumVec ] = binningSpectrum( dataVec, mzAxis, tol );
end
dataVec_LN = dataVec; mzAxis_LN = mzAxis;