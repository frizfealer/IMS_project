addpath( '/csbiohome01/ycharn ');
startup
load( '/csbiohome01/ycharn/IMS_project-master/example/realExp_100831_348_136_12_40hr_0-1XLB_LN/100831_348_136_12_40hr_0_1XLB_LN_input_20141231.mat' );
iD = initD( dataCube, nDTemplate, 'NNMF', nDIonName);
[df, lambda] = testLambdaMax( dataCube, iD, 1, 1, 1e-1, 1,0.030873, 5e-2 );
save( 'testLambdaScript_11_.mat', 'df', 'lambda' )